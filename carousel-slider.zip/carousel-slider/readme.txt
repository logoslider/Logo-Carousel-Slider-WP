=== Logo Carousel Slider WP ===
Contributors: logoslider
Author URI: https://github.com/logoslider/Logo-Carousel-Slider-WP
Donate link: https://github.com/logoslider/Logo-Carousel-Slider-WP
Tags:logo carousel slider
Requires at least: 3.2
Tested up to: 4.9.8
Requires PHP: 5.2.4
Stable tag: 1.0.0
License: GPLv3 or later

A simple plugin which can to display Logo Slider by insert logoslider shortcode 

== Description ==

Logo Carousel Slider WP can help webmaster make a Logo Carousel Slider very easy and fast, you can use it like this way:

[logoslider logourl="<img src='http://yourdomain.com/wp-content/uploads/2018/01/example1.png'>,<img src='http://yourdomain.com/wp-content/uploads/2018/01/example2.png'>,<img src='http://yourdomain.com/wp-content/uploads/2018/01/example3.jpg'>,<img src='http://yourdomain.com/wp-content/uploads/2018/01/example4.png'>,<img src='http://yourdomain.com/wp-content/uploads/2018/01/example5.png'>,<img src='http://yourdomain.com/wp-content/uploads/2018/01/example6.png'>,<img src='http://yourdomain.com/wp-content/uploads/2018/01/example7.png'>,<img src='http://yourdomain.com/wp-content/uploads/2018/02/example8.png'>"]

Basically, what you need to do is just copy your image url in the shortcode [logoslider], then the shortcode will make a Logo Carousel Slider for you, you can insert it in yout wordpress standard editor, or insert it in your advanced editor, it will works well, that's all.

== Installation ==

1:Upload logo carousel slider plugin to your wordpress site
2:Activate it 
3: Use shortcode to insert logo carousel slider into any page or post
That's all

== Frequently Asked Questions ==
Any question? Or any feature request? Submit ticket at our wordpress support form

== Screenshots ==

== Changelog ==
= Version 1.0.0 =
logo carousel slider 1.0.0

